package com.evva.xesar.abrevva_example

import android.os.Bundle
import android.os.PersistableBundle
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity() {}
